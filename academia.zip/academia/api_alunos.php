<?php
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Configurações do banco de dados
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'academia';

// Conexão com o banco de dados
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    http_response_code(500);
    die(json_encode(['error' => 'Falha na conexão com o banco de dados.']));
}

// Lógica para listar todos os alunos (GET)
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $sql = "SELECT id, nome_usuario FROM usuarios WHERE role = 'aluno'";
    $result = mysqli_query($conn, $sql);

    $alunos = [];
    while ($row = mysqli_fetch_assoc($result)) {
        // === CORREÇÃO: Converte o ID para int antes de enviar para o Flutter ===
        $alunos[] = ['id' => (int)$row['id'], 'nome_usuario' => $row['nome_usuario']];
    }
    
    echo json_encode($alunos);

// Lógica para adicionar um novo aluno (POST)
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!isset($data['nome_usuario'], $data['senha'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Dados incompletos.']);
        exit();
    }
    $stmt = $conn->prepare("INSERT INTO usuarios (nome_usuario, senha_hash, role) VALUES (?, ?, 'aluno')");
    $stmt->bind_param("ss", $data['nome_usuario'], $data['senha']);
    if ($stmt->execute()) {
        echo json_encode(['success' => 'Aluno adicionado com sucesso.']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Falha ao adicionar aluno.']);
    }

// Lógica para editar um aluno (PUT)
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (empty($id) || !isset($data['nome_usuario'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Dados incompletos.']);
        exit();
    }

    $nome_usuario = $data['nome_usuario'];
    $senha = isset($data['senha']) ? $data['senha'] : null;

    if ($senha) {
        $stmt = $conn->prepare("UPDATE usuarios SET nome_usuario = ?, senha_hash = ? WHERE id = ?");
        $stmt->bind_param("ssi", $nome_usuario, $senha, $id);
    } else {
        $stmt = $conn->prepare("UPDATE usuarios SET nome_usuario = ? WHERE id = ?");
        $stmt->bind_param("si", $nome_usuario, $id);
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Aluno atualizado com sucesso.']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Falha ao atualizar aluno.']);
    }

// Lógica para deletar um aluno (DELETE)
} elseif ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    if (empty($id)) {
        http_response_code(400);
        echo json_encode(['error' => 'ID do aluno não fornecido.']);
        exit();
    }
    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo json_encode(['success' => 'Aluno excluído com sucesso.']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Falha ao excluir aluno.']);
    }

} else {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido.']);
}
$conn->close();
?>