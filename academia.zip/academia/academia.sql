-- Cria o banco de dados 'academia'
CREATE DATABASE IF NOT EXISTS academia;
USE academia;

-- Remove as tabelas se elas já existirem para evitar erros
DROP TABLE IF EXISTS exercicios;
DROP TABLE IF EXISTS usuarios;

-- Cria a tabela 'usuarios' com o campo 'role'
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_usuario VARCHAR(50) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL, -- Coluna para senha. O ideal é usar hash.
    role VARCHAR(50) NOT NULL DEFAULT 'aluno' -- 'professor' ou 'aluno'
);

-- Cria a tabela 'exercicios'
CREATE TABLE exercicios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    series INT NOT NULL,
    repeticoes INT NOT NULL,
    observacao VARCHAR(255),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Insere usuários de exemplo
-- A senha '123' não está com hash, é apenas para fins didáticos.
INSERT INTO usuarios (nome_usuario, senha_hash, role) VALUES
('joao', '123', 'professor'),
('maria', 'abc', 'aluno'),
('diego', 'senha', 'aluno');

-- Insere exercícios para os usuários
INSERT INTO exercicios (id_usuario, nome, series, repeticoes, observacao)
VALUES
( (SELECT id FROM usuarios WHERE nome_usuario = 'joao'), 'Caminhada', 1, 30, 'Aquecimento'),
( (SELECT id FROM usuarios WHERE nome_usuario = 'joao'), 'Corrida', 1, 20, 'Cardio'),
( (SELECT id FROM usuarios WHERE nome_usuario = 'maria'), 'Supino Reto', 3, 12, 'Peso leve'),
( (SELECT id FROM usuarios WHERE nome_usuario = 'maria'), 'Agachamento', 4, 10, 'Postura correta'),
( (SELECT id FROM usuarios WHERE nome_usuario = 'diego'), 'Esteira', 1, 20, 'Aquecimento'),
( (SELECT id FROM usuarios WHERE nome_usuario = 'diego'), 'Levantamento Terra', 3, 8, 'Aumentar carga');