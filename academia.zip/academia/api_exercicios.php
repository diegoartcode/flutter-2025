<?php
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Configurações do banco de dados
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'academia';

// Conexão com o banco de dados
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    http_response_code(500);
    die(json_encode(['error' => 'Falha na conexão com o banco de dados.']));
}

// Lógica para lidar com requisições GET
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $username = isset($_GET['user']) ? $_GET['user'] : '';

    if (empty($username)) {
        http_response_code(400);
        echo json_encode(['error' => 'Parâmetro de usuário não fornecido.']);
        exit();
    }

    $stmt = $conn->prepare("
        SELECT e.id, e.nome, e.series, e.repeticoes, e.observacao
        FROM exercicios e
        JOIN usuarios u ON e.id_usuario = u.id
        WHERE u.nome_usuario = ?
    ");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    $exercicios = [];
    while ($row = $result->fetch_assoc()) {
        $exercicios[] = $row;
    }

    echo json_encode($exercicios);

// Lógica para lidar com requisições POST
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!isset($data['nome_aluno'], $data['nome'], $data['series'], $data['repeticoes'], $data['observacao'], $data['role']) || $data['role'] !== 'professor') {
        http_response_code(403);
        echo json_encode(['error' => 'Acesso negado. Apenas professores podem adicionar exercícios.']);
        exit();
    }

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE nome_usuario = ?");
    $stmt->bind_param("s", $data['nome_aluno']);
    $stmt->execute();
    $user_result = $stmt->get_result();

    if ($user_result->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Usuário (aluno) não encontrado.']);
        exit();
    }
    $user_id = $user_result->fetch_assoc()['id'];

    $stmt = $conn->prepare("INSERT INTO exercicios (id_usuario, nome, series, repeticoes, observacao) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isiss", $user_id, $data['nome'], $data['series'], $data['repeticoes'], $data['observacao']);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Exercício adicionado com sucesso.']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Falha ao adicionar exercício.']);
    }

// Lógica para lidar com requisições DELETE
} elseif ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    $role = isset($_GET['role']) ? $_GET['role'] : '';

    if ($role !== 'professor') {
        http_response_code(403);
        echo json_encode(['error' => 'Acesso negado. Apenas professores podem excluir exercícios.']);
        exit();
    }
    
    if (empty($id)) {
        http_response_code(400);
        echo json_encode(['error' => 'ID do exercício não fornecido.']);
        exit();
    }

    $stmt = $conn->prepare("DELETE FROM exercicios WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Exercício excluído com sucesso.']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Falha ao excluir o exercício.']);
    }

// Lógica para lidar com requisições PUT (editar)
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!isset($data['role']) || $data['role'] !== 'professor') {
        http_response_code(403);
        echo json_encode(['error' => 'Acesso negado. Apenas professores podem editar exercícios.']);
        exit();
    }
    
    if (empty($id)) {
        http_response_code(400);
        echo json_encode(['error' => 'ID do exercício não fornecido para a edição.']);
        exit();
    }

    if (!isset($data['nome'], $data['series'], $data['repeticoes'], $data['observacao'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Dados incompletos para a edição.']);
        exit();
    }

    $stmt = $conn->prepare("
        UPDATE exercicios
        SET nome = ?, series = ?, repeticoes = ?, observacao = ?
        WHERE id = ?
    ");
    $stmt->bind_param("sissi", $data['nome'], $data['series'], $data['repeticoes'], $data['observacao'], $id);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Exercício atualizado com sucesso.']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Falha ao atualizar o exercício.']);
    }

} else {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido.']);
}

$conn->close();
?>