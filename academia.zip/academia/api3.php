<?php
header("Content-Type: application/json; charset=UTF-8");

// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$pdo = new PDO("mysql:host=localhost;dbname=lojaFlutter;charset=utf8", "root", "");

// Método GET (listar produtos)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->query("SELECT * FROM produtos");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

// Método POST (cadastrar produto)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("INSERT INTO produtos (nome, preco, descricao) VALUES (?, ?, ?)");
    $stmt->execute([$data['nome'], $data['preco'], $data['descricao']]);
    echo json_encode(["message" => "Produto cadastrado com sucesso!"]);
}

// Método PUT (editar produto)
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("UPDATE produtos SET nome=?, preco=?, descricao=? WHERE id=?");
    $stmt->execute([$data['nome'], $data['preco'], $data['descricao'], $data['id']]);
    echo json_encode(["message" => "Produto atualizado com sucesso!"]);
}

// Método DELETE (excluir produto)
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("DELETE FROM produtos WHERE id=?");
    $stmt->execute([$data['id']]);
    echo json_encode(["message" => "Produto excluído com sucesso!"]);
}
