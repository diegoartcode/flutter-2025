<?php
header("Content-Type: application/json; charset=UTF-8");

// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");

// Se for requisição OPTIONS (preflight), só responde OK e encerra
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lojaFlutter";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Falha na conexão"]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $sql = "SELECT * FROM produtos WHERE id=$id";
            $result = $conn->query($sql);
            echo json_encode($result->fetch_assoc());
        } else {
            $sql = "SELECT * FROM produtos";
            $result = $conn->query($sql);
            $data = [];
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            echo json_encode($data);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nome = $conn->real_escape_string($data['nome']);
        $preco = floatval($data['preco']);
        $descricao = $conn->real_escape_string($data['descricao']);
        $sql = "INSERT INTO produtos (nome, preco, descricao) VALUES ('$nome', $preco, '$descricao')";
        if ($conn->query($sql)) {
            echo json_encode(["message" => "Produto cadastrado"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Erro ao cadastrar"]);
        }
        break;

    case 'PUT':
        parse_str(file_get_contents("php://input"), $data);
        $id = intval($data['id']);
        $nome = $conn->real_escape_string($data['nome']);
        $preco = floatval($data['preco']);
        $descricao = $conn->real_escape_string($data['descricao']);
        $sql = "UPDATE produtos SET nome='$nome', preco=$preco, descricao='$descricao' WHERE id=$id";
        if ($conn->query($sql)) {
            echo json_encode(["message" => "Produto atualizado"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Erro ao atualizar"]);
        }
        break;

    case 'DELETE':
        parse_str(file_get_contents("php://input"), $data);
        $id = intval($data['id']);
        $sql = "DELETE FROM produtos WHERE id=$id";
        if ($conn->query($sql)) {
            echo json_encode(["message" => "Produto excluído"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Erro ao excluir"]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Método não permitido"]);
}
$conn->close();
