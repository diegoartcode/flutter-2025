<?php
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'academia';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    http_response_code(500);
    die(json_encode(['error' => 'Falha na conexão com o banco de dados.']));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!isset($data['user']) || !isset($data['pass'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Dados incompletos.']);
        exit();
    }

    $stmt = $conn->prepare("SELECT nome_usuario, senha_hash, role FROM usuarios WHERE nome_usuario = ? AND senha_hash = ?");
    $stmt->bind_param("ss", $data['user'], $data['pass']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user_data = $result->fetch_assoc();
        echo json_encode([
            'success' => true,
            'role' => $user_data['role']
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Usuário ou senha inválidos.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido.']);
}

$conn->close();
?>